export { AnketaPage } from './AnketaPage';
