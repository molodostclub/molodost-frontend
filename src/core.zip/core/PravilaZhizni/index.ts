export { PravilaZhizni } from './PravilaZhizni';
