export { OurAltay } from './OurAltay';
