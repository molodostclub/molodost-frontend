export { Motto } from './Motto';
