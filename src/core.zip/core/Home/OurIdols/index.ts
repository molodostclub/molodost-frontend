export { OurIdols } from './OurIdols';
