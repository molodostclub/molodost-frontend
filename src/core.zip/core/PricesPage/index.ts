export { PricesPage } from './PricesPage';
