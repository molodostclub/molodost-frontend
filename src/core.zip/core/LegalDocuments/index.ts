export { LegalDocuments } from './LegalDocuments';
